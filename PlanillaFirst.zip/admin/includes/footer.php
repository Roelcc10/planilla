<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>@<a href="#">First Image</a></b>
    </div>
    <strong>Copyright © 2020. Todos los derechos reservados | Diseñado por: <img src="http://enterate.com/wp-content/themes/enterate.com/assets/img/first.png" width="150px" alt=""></strong>
</footer>